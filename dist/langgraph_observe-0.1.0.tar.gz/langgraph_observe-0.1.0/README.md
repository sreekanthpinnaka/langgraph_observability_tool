# 🔭 langgraph-observe

> A completely separate, standalone observability server, real-time web dashboard, and universal client SDK for **LangGraph workflows in ANY FastAPI backend**.

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100+-green.svg)](https://fastapi.tiangolo.com/)
[![LangGraph](https://img.shields.io/badge/LangGraph-0.1+-indigo.svg)](https://github.com/langchain-ai/langgraph)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 🏛️ Architecture: Completely Decoupled & Distributed

`langgraph-observe` is designed to be **completely decoupled** from your applications. It runs as an independent service on its own port or container, while your FastAPI backends stream execution traces asynchronously over HTTP with zero performance penalty.

```
┌────────────────────────────────────────────────────────┐
│               ANY FastAPI Backend (Anywhere)           │
│    (Localhost, Docker, Kubernetes, AWS, Cloud Run)     │
│                                                        │
│  FastAPI Backend (Port 8000)                           │
│    ├── instrument_fastapi(app, "http://obs-server")    │
│    └── LangGraph Workflow (observe_graph)              │
│    └── Async Background Exporter (Queue + Non-blocking)│
└──────────────────────────┬─────────────────────────────┘
                           │
                 Async HTTP POST /api/v1/traces
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│     Standalone LangGraph Observability Server (Port 8765)
│                                                        │
│  ├── Ingestion API:  POST /api/v1/traces               │
│  ├── Batch Ingest:   POST /api/v1/traces/batch         │
│  ├── Query APIs:     GET /api/v1/traces, /stats        │
│  ├── SQLite Storage: observe.db (WAL mode)             │
│  └── Web Dashboard:  GET / (Interactive UI)           │
└──────────────────────────┬─────────────────────────────┘
                           │
             http://localhost:8765/
                           │
                           ▼
           👨‍💻 Developer / Engineering Team
```

---

## 🌟 Key Capabilities

- 🚀 **Completely Decoupled Observability Service**: Runs as a standalone server (`py -m langgraph_observe server --port 8765` or `langgraph-observe server`). No storage or UI clutter inside your backend apps!
- 🔌 **Universal Client SDK**: Works on **any** FastAPI backend running **anywhere** (local, cloud, Docker, k8s) with a single `instrument_fastapi(app)` line.
- 🛡️ **Zero-Overhead & Fault-Tolerant**: Traces are queued and dispatched in the background. Even if the observability server is offline or unreachable, your backend application is never impacted.
- ⚡ **Universal LangGraph Support**: Traces **any** LangGraph workflow (`StateGraph`, `MessageGraph`, multi-agent graphs, conditional routing, subgraphs).
- 🧬 **Automatic State Diffs**: Automatically calculates state mutations before and after each node executes, highlighting added, modified, or appended items.
- 📊 **Waterfall Gantt Timeline**: Interactive visual breakdown showing execution timing across HTTP requests, nodes, LLMs, and tool calls.
- 🤖 **LLM & Tool Observability**: Inspect prompts, system instructions, model parameters, completions, and token usage.
- 🖥️ **Embedded Live Dashboard**: Interactive dark-mode dashboard with auto-refresh, search, status filters, and JSON export.

---

## 🚀 Quickstart: 2 Steps

### Step 1: Start the Standalone Observability Server

Run the standalone server on your preferred port (default `8765`):

```bash
py -m langgraph_observe server --port 8765
```

Open your browser at:
👉 **`http://localhost:8765/`**

---

### Step 2: Instrument ANY FastAPI Backend

In your FastAPI backend application (running anywhere on port 8000, in Docker, or on a remote machine):

```python
from fastapi import FastAPI
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph_observe import instrument_fastapi, observe_graph

# 1. Your FastAPI Application
app = FastAPI(title="Payment Service")

# 2. Point to the separate observability server
instrument_fastapi(app, server_url="http://localhost:8765")

# 3. Define any LangGraph workflow
class WorkflowState(TypedDict):
    query: str
    result: str

builder = StateGraph(WorkflowState)
builder.add_node("process", lambda s: {"result": f"Answer for: {s['query']}"})
builder.add_edge(START, "process")
builder.add_edge("process", END)

# 4. Wrap with observe_graph
workflow = observe_graph(builder.compile(), name="PaymentWorkflow")

# 5. Call in your endpoint (tracing is fully automatic!)
@app.post("/checkout")
async def checkout(payload: dict):
    return await workflow.ainvoke({"query": payload["query"], "result": ""})
```

Start your backend application:
```bash
py -m uvicorn backend:app --port 8000
```

Trigger a request:
```bash
curl -X POST http://localhost:8000/checkout -H "Content-Type: application/json" -d "{\"query\": \"Order #123\"}"
```

The response includes an `X-Trace-ID` header, and the full execution trace immediately appears on the standalone dashboard at `http://localhost:8765/`!

---

## 🗄️ Database Configuration (Google Cloud SQL / MySQL)

By default, `langgraph-observe` stores traces locally in SQLite (`observe.db`). For production environments and horizontal scaling, you can point it to **Google Cloud SQL (MySQL)** simply by setting `DATABASE_URL` in your `.env` file or passing `--db-url`.

### 1. Configure via `.env` file

Create a `.env` file in your root folder:

```env
# Option A: Google Cloud SQL via Public IP (Authorized Networks)
DATABASE_URL=mysql+pymysql://observe_user:SecurePassword123!@34.123.45.67:3306/observe_db

# Option B: Google Cloud SQL via Cloud SQL Auth Proxy (Recommended GCP practice)
# DATABASE_URL=mysql+pymysql://observe_user:SecurePassword123!@127.0.0.1:3306/observe_db
```

### 2. Built-in Cloud SQL Production Optimizations

When a MySQL database URL is detected:
- **Connection Pre-Ping (`pool_pre_ping=True`)**: Automatically checks connection liveness before executing queries to prevent broken pipe errors.
- **Connection Recycling (`pool_recycle=1800`)**: Recycles connections every 30 minutes, preventing Cloud SQL from dropping idle connections ("MySQL server has gone away").
- **Automatic Schema Migration**: The `traces` table, indexes on `start_time`, `status`, and `name`, and `LONGTEXT` JSON columns are created automatically on startup.

---

## 💻 CLI Reference

Launch the standalone server with custom options:

```bash
# Start server on default port 8765 (reads DATABASE_URL from .env if present)
py -m langgraph_observe server

# Or pass database URL explicitly via CLI
py -m langgraph_observe server --db-url "mysql+pymysql://user:pass@34.123.45.67:3306/observe_db"

# Custom port, host, and SQLite fallback file
py -m langgraph_observe server --host 0.0.0.0 --port 9000 --db /data/traces.db
```

| Flag | Default | Description |
|---|---|---|
| `--port` | `8765` | Port to bind the server |
| `--host` | `127.0.0.1` | Network interface to listen on (`0.0.0.0` for all) |
| `--db-url` | `None` | Database URL (MySQL, PostgreSQL, etc.). Falls back to `DATABASE_URL` in `.env` |
| `--db` | `observe.db` | SQLite fallback database filepath |
| `--reload` | `False` | Enable auto-reload for development |

---

## 📡 Standalone Server REST APIs

The server exposes standard REST APIs for ingestion and external tools:

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/` | Interactive Web Dashboard (HTML) |
| `POST` | `/api/v1/traces` | Ingest single trace from remote client |
| `POST` | `/api/v1/traces/batch` | Ingest batch of traces |
| `GET` | `/api/v1/traces` | List traces with pagination, status, and search filters |
| `GET` | `/api/v1/traces/{id}` | Complete trace details (spans, state diffs, LLM data) |
| `GET` | `/api/v1/stats` | Aggregated performance metrics & node breakdown |
| `DELETE` | `/api/v1/traces/{id}` | Delete a trace |
| `DELETE` | `/api/v1/traces` | Clear trace history |
| `GET` | `/api/v1/export/{id}` | Export trace as downloadable JSON file |
| `GET` | `/health` | Server health check (`{"status": "healthy"}`) |

---

## 🧪 Testing

Run the complete test suite:

```bash
py -m pytest -v
```

---

## 📦 Project Structure

The codebase is strictly structured into three decoupled layers: `server/`, `client/`, and `core/`:

```
d:/observe/
├── langgraph_observe/
│   ├── core/                     # Shared domain models & utilities
│   │   ├── models.py             # Trace, Span, SpanType, HTTPMetadata
│   │   ├── serializer.py         # Safe recursion serialization & state diffing
│   │   └── context.py            # Async-safe task-local ContextVar manager
│   │
│   ├── server/                   # Standalone Observability Server & Dashboard
│   │   ├── app.py                # FastAPI ingestion server & query REST APIs
│   │   ├── cli.py                # CLI runner (langgraph-observe server)
│   │   ├── storage/              # Pluggable persistence layer
│   │   │   ├── base.py           # BaseStorage abstract interface
│   │   │   ├── sql.py            # SQLAlchemyStorage (Google Cloud SQL MySQL & generic SQL)
│   │   │   ├── sqlite.py         # High-speed SQLite (WAL mode, indexed queries)
│   │   │   └── memory.py         # Ephemeral In-Memory Storage (for unit testing)
│   │   └── ui/                   # Embedded Web Dashboard
│   │       └── index.html        # Interactive dark-mode dashboard UI
│   │
│   └── client/                   # Lightweight Tracing SDK for ANY FastAPI Backend
│       ├── instrument.py         # instrument_fastapi(app, server_url)
│       ├── middleware.py         # LangGraphObserveMiddleware (Starlette HTTP interceptor)
│       ├── collector.py          # In-memory Span & Trace aggregator
│       ├── exporter.py           # RemoteStorage / AsyncRemoteExporter (background queue)
│       └── langgraph/            # LangGraph integration
│           ├── callback.py       # LangGraphTraceCallbackHandler (stack-free run_id tree)
│           └── wrapper.py        # observe_graph wrapper & @observe_workflow decorator
│
├── examples/
│   ├── remote_backend_app.py     # Independent FastAPI backend streaming to server
│   ├── app.py                    # Single-process in-app mount example
│   └── simulate_traffic.py       # High-volume traffic simulator
│
├── tests/                        # 19 comprehensive unit & integration tests
├── pyproject.toml
└── README.md
```

---

## 📄 License

MIT
